#ifndef FWD_H
#define FWD_H

struct eliza_state;

#endif
