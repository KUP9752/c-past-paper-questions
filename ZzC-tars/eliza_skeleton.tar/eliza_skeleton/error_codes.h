#ifndef ERROR_CODES_H
#define ERROR_CODES_H

enum
{
  REGEX_FAILURE
};

#endif
