#ifndef PARSER_H
#define PARSER_H

#include "fwd.h"

int parse_eliza_script(struct eliza_state *eliza, const char *path);

#endif
