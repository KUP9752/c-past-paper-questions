#include "doublets.h"

/* ------------------ YOUR CODE HERE ------------------- */

bool valid_step(dictionary_t *dict, const char *curr_word, const char *next_word) {
  return false;
}

void print_chain(const char **chain) {
  return;
}

bool valid_chain(dictionary_t *dict, const char **chain) {
  return false;
}

bool find_chain(dictionary_t *dict, const char *start_word, 
                const char *target_word, const char **chain, int max_words) {
  return false;
}

